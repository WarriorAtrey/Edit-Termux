# Edit-Tool
Customize Your Termux


### Installation and usage guide
```
```
$ apt-get update -y
```
```
$ apt-get upgrade -y
```
```
$ pkg install git -y
```
```
$ git clone https://github.com/noob-hackers/T-LOAD
```
```
$ ls
```
```
$ cd T-LOAD
```
```
$ ls
```
```
$ bash t-load.sh
```
```
* Now make sue that you internet connection is on and after that the installation starts automatically
```
```
* After the installation succesfully completes you will see a THANKS text on screen after that a new text appears 
```
```
* EXIT FROM TERMUX AFTER 5 SECONDS AND RE-OPEN IT after seeing this just exit from termux and re open it 
```
```
Now you can see a new loading screen of termux and you can feel real hacking terminal Sound+New interface with banner. 
```
```
Note:- Don't delete any of the audio files from your sdcard/internal storage or else you cannot feel the terminal startup sound
```
```
To revert/to get back into normal termux mode use this commands
```
```
cd T-LOAD
```
ls
```
bash rvt.sh
```
```

### Subscribe our channel on youtube


### Chekout our webite 

     
### Warning

***This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases.***
