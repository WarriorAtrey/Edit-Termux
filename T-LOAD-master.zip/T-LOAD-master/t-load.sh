#!Script  author N117R0
#By noob hackers
#Be a creative person not copy paster

###################################
cyan='\e[0;36m'

lightgreen='\e[1;32m'

red='\e[1;31m'

yellow='\e[1;33m'
###################################

clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo -e "\e[1m\e[31m\
           
           ████████╗   ██╗      ██████╗  █████╗ ██████╗
           ╚══██╔══╝   ██║     ██╔═══██╗██╔══██╗██╔══██╗
              ██║█████╗██║     ██║   ██║███████║██║  ██║
              ██║╚════╝██║     ██║   ██║██╔══██║██║  ██║
              ██║      ███████╗╚██████╔╝██║  ██║██████╔╝
              ╚═╝      ╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝ v 1.1"
echo " "  
echo -e  "                  \e[1m\e[32m▂▃▄▅▆▇▓▒░Coded By \e[31mN17R0 \e[1m\e[32m░▒▓▇▆▅▄▃▂"
echo "                      -------------------------"
echo -e  "            \e[1m\e[32m--------->[\e[31myoutube.com/noobhackers\e[1m\e[32m]<----------"  
echo " "
echo ""
sleep 8.0
pkg install mpv -y
termux-setup-storage
cd  /data/data/com.termux/files/usr/etc

rm bash.bashrc

ls

cd $HOME

ls 

cd T-LOAD

ls

cp bash.bashrc /data/data/com.termux/files/usr/etc

ls

cd $HOME

ls

cd T-LOAD

ls

cp scifi.mp3 /sdcard

clear
bash packages.sh
clear
sleep 4.0
bash ins.sh 
sleep 5.0
clear
sleep 5.0
bash thanks.sh 
sleep 2.0 
clear
echo " "
echo " "
echo " "
echo " "
echo " "
echo "             "EXIT FROM TERMUX AND RE OPEN IT AFTER 5 SECONDS |lolcat 
echo " "
echo " "
sleep 3.0
cd $HOME
